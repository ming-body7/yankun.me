<?php get_header(); ?>
<div class="content-area-wrap">
</div>
<?php get_footer(); ?>