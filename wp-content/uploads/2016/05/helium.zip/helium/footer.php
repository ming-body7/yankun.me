
		</div>

	</div>

</body>

<?php wp_footer(); ?>

</html>
